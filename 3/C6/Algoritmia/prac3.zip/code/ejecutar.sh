#!/bin/bash
# ======================================================================
# Script de automatización - Práctica 3: Búsqueda con retroceso
# ======================================================================

echo "========================================"
echo "⚙️ Compilando ubicaCentros.cpp..."
echo "========================================"
# Usamos -std=c++11 y -O3 para máximo rendimiento
g++ -std=c++11 -O3 ubicaCentros.cpp -o ubicaCentros

# Verificamos si el comando anterior (g++) terminó con éxito
if [ $? -eq 0 ]; then
    echo "✅ Compilación exitosa."
    echo ""
    echo "========================================"
    echo "🚀 Ejecutando casos de prueba..."
    echo "========================================"
    
    # Ejecutamos el programa pasando los ficheros requeridos
    ./ubicaCentros pruebas.txt resultados.txt

    echo "✅ Ejecución terminada. Contenido de resultados.txt:"
    echo "----------------------------------------"
    cat resultados.txt
    echo "----------------------------------------"
    echo "¡Pruebas finalizadas!"
else
    echo "❌ Error de compilación. Por favor, revisa el código."
fi