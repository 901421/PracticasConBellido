/*
 * ===============================================================================
 * PRÁCTICA 3: BÚSQUEDA CON RETROCESO - Jorge Bellido(903080), Imad Habib(901421)
 * ===============================================================================
 * * Algoritmia Basica — Practica 3: Busqueda con retroceso
 * Problema: ubicacion optima de k nuevos centros de urgencias en un grafo
 *           ponderado no dirigido para minimizar el peor tiempo de acceso.
 *
 * Uso: ./ubicaCentros <fichero_entrada> <fichero_salida>
 */
 
#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>
 
using namespace std;
 
const int INF = 1e8;
 
struct Contexto {
    // Variables del caso de prueba activo
    int n;                        // Numero de localidades (vertices del grafo)
    int m;                        // Numero de carreteras (aristas del grafo)
    int c;                        // Numero de centros de urgencias ya operativos
    int k;                        // Numero de nuevos centros a instalar
    
    vector<vector<int>> dist;     // dist[i][j]: tiempo minimo entre localidades i y j
    vector<vector<int>> min_dist_suffix; // guarda la distancia mínima desde la localidad 'u'
    
    // Variables de estado del backtracking    
    int          mejor_coste;     // Minimo peor tiempo de acceso encontrado hasta ahora
    vector<int>  mejor_sol;       // Localidades (0-based) de la mejor solucion hallada
    long long    n_nodos;         // Nodos del arbol de busqueda generados
};
 
// ---------------------------------------------------------------------------
// Funciones auxiliares
// ---------------------------------------------------------------------------
 
/*
 * Devuelve el maximo del vector 'accesos', que representa el peor tiempo
 * de acceso a un centro entre todas las localidades
 */

int coste_maximo(const vector<int>& accesos) {
    int max_t = 0;
    for (int t : accesos) if (t > max_t) max_t = t;
    return max_t;
}
 
// ---------------------------------------------------------------------------
// Backtracking
// ---------------------------------------------------------------------------
 
/*
 * Explora el arbol de soluciones en busca del subconjunto optimo de k
 * localidades donde instalar los nuevos centros.
 *
 * nivel   : numero de centros nuevos ya fijados en esta rama.
 * inicio  : menor indice candidato a considerar; garantiza que los centros
 *           elegidos esten siempre en orden creciente, evitando explorar
 *           permutaciones equivalentes como {1,3} y {3,1}.
 * sol     : indices 0-based de los centros elegidos hasta el nivel actual.
 * accesos : accesos[u] = tiempo minimo de u al centro mas cercano,
 *           considerando los centros existentes y los elegidos hasta ahora.
 */
void backtrack(int nivel, int inicio, vector<int>& sol, vector<int>& accesos, Contexto& ctx) {
    ctx.n_nodos++;
 
    // --- Caso base: solucion completa con k centros nuevos ---
    if (nivel == ctx.k) {
        int coste_final = coste_maximo(accesos);
        if (coste_final < ctx.mejor_coste) {
            ctx.mejor_coste = coste_final;
            ctx.mejor_sol   = sol;
        }
        return;
    }
 
    // Poda combinatoria (si no quedan suficientes localidades para llegar a k)
    if (ctx.n - inicio < ctx.k - nivel) return;

    //Poda por Cota Inferior 
    // Evaluamos si alguna localidad quedará inevitablemente con un acceso peor o igual 
    // al 'mejor_coste' actual, incluso si elegimos los mejores centros restantes.
    for (int u = 0; u < ctx.n; u++) {
        if (min(accesos[u], ctx.min_dist_suffix[u][inicio]) >= ctx.mejor_coste) {
            return; // Imposible mejorar el mejor coste global, podamos la rama.
        }
    }
 
    // Backup para optimizar memoria
    vector<int> copia_accesos = accesos; 
 
    
    for (int v = inicio; v < ctx.n; v++) {
        sol.push_back(v);
        
        // Calcular los nuevos tiempos de acceso al abrir el centro en v.
        // Para cada localidad u, su acceso mejora si v esta mas cerca que
        // cualquier centro anterior.
        for (int u = 0; u < ctx.n; u++) {
            if (ctx.dist[u][v] < accesos[u]) {
                accesos[u] = ctx.dist[u][v];
            }
        }
 
        backtrack(nivel + 1, v + 1, sol, accesos, ctx);
 
        // Restaurar estado
        accesos = copia_accesos;
        sol.pop_back();
 
        // Poda absoluta: si ya es 0, no podemos mejorar más
        if (ctx.mejor_coste == 0) return;
    }
}

// ---------------------------------------------------------------------------
// Resolucion de un caso de prueba
// ---------------------------------------------------------------------------
 
/*
 * Lee un caso del fichero 'entrada', lo resuelve y escribe el resultado
 * en 'salida'.
 *
 * Formato de salida por caso:
 *   tiempo_ms n_nodos valor_optimo s1 s2 ... sk
 */
void resolver(ifstream& entrada, ofstream& salida) {
    Contexto ctx;
    if (!(entrada >> ctx.n >> ctx.m >> ctx.c >> ctx.k)) return; 
 
    // --- Inicializar matriz de distancias ---
    // Diagonal a 0; resto a INF hasta leer las aristas.
    ctx.dist.assign(ctx.n, vector<int>(ctx.n, INF));
    for (int i = 0; i < ctx.n; i++) ctx.dist[i][i] = 0;
 
    // Leer aristas. El fichero usa indices 1-based; internamente usamos 0-based.
    for (int i = 0; i < ctx.m; i++) {
        int u, v, t;
        entrada >> u >> v >> t;
        u--; v--;
        // Grafo no dirigido: actualizamos ambas direcciones.
        // Si hay aristas paralelas nos quedamos con la mas rapida.
        if (t < ctx.dist[u][v]) {
            ctx.dist[u][v] = t;
            ctx.dist[v][u] = t;
        }
    }

    // --- Floyd-Warshall ---
    // Calcula el tiempo minimo de viaje entre todos los pares de localidades.
    // Los pares sin camino conservan el valor INF al terminar.
    for (int inter = 0; inter < ctx.n; inter++) {
        for (int i = 0; i < ctx.n; i++) {
            if (ctx.dist[i][inter] < INF) {
                for (int j = 0; j < ctx.n; j++) {
                    if (ctx.dist[inter][j] < INF) {
                        ctx.dist[i][j] = min(ctx.dist[i][j], ctx.dist[i][inter] + ctx.dist[inter][j]);
                    }
                }
            }
        }
    }
    
    vector<int> existentes(ctx.c);
    vector<int> accesos_ini(ctx.n, INF);
    for (int i = 0; i < ctx.c; i++) {
        entrada >> existentes[i];
        existentes[i]--; // Convertir a 0-based
    }

    // Precalculamos la distancia mínima desde cualquier nodo 'u' a cualquier subconjunto 
    // de candidatos restantes [i ... n-1]. Se calcula de atrás hacia adelante.
    ctx.min_dist_suffix.assign(ctx.n, vector<int>(ctx.n + 1, INF));
    
    // --- Calcular tiempos de acceso iniciales ---
    // Para cada localidad u, su acceso inicial es la distancia minima a
    // cualquiera de los c centros ya operativos.
    for (int u = 0; u < ctx.n; u++) {
        if (ctx.c == 0) { accesos_ini[u] = INF; continue; }
        for (int e : existentes) {
            accesos_ini[u] = min(accesos_ini[u], ctx.dist[u][e]);
        }
    }
 
    // Inicializamos con un valor que garantice que cualquier solución k sea mejorada
    ctx.mejor_coste = INF + 7;
    ctx.mejor_sol.clear();
    ctx.n_nodos = 0;
 
    auto t0 = chrono::high_resolution_clock::now();
    vector<int> sol;
    sol.reserve(ctx.k);
    
    // Siempre ejecutamos backtrack si k > 0 para encontrar la mejor combinación
    if (ctx.k > 0) {
        backtrack(0, 0, sol, accesos_ini, ctx);
    } else {
        ctx.mejor_coste = coste_maximo(accesos_ini);
    }
 
    auto t1 = chrono::high_resolution_clock::now();
    long long tiempo_ms = chrono::duration_cast<chrono::milliseconds>(t1 - t0).count();
 
    // --- Escribir resultado ---
    // Los indices se convierten de 0-based a 1-based para la salida.
    // mejor_sol ya esta ordenado de forma creciente por construccion del arbol.
    salida << tiempo_ms << " " << ctx.n_nodos << " " << ctx.mejor_coste;
    for (int v : ctx.mejor_sol) salida << " " << (v + 1);
    salida << "\n";
}
 
// ---------------------------------------------------------------------------
// Punto de entrada
// ---------------------------------------------------------------------------
 
int main(int argc, char* argv[]) {
 
    if (argc != 3) {
        cerr << "Uso: ubicaCentros <fichero_entrada> <fichero_salida>\n";
        return 1;
    }
 
    ifstream entrada(argv[1]);
    if (!entrada.is_open()) {
        cerr << "Error: no se puede abrir '" << argv[1] << "'\n";
        return 1;
    }
 
    ofstream salida(argv[2]);
    if (!salida.is_open()) {
        cerr << "Error: no se puede abrir '" << argv[2] << "'\n";
        return 1;
    }
 
    int num_casos;
    if (!(entrada >> num_casos)) return 0;
 
    for (int i = 0; i < num_casos; i++)
        resolver(entrada, salida);
 
    return 0;
}
 